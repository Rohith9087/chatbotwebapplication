let chatbotMsgList = ["Hi", "Hey", "Good Morning", "Good Evening", "How can I help you?", "Thank You"];

let chatContainerE1 = document.getElementById("chatContainer");
let userInputE1 = document.getElementById("userInput");

function userChat() {
    let userMsg = userInput.value;

    let msgContainerE1 = document.createElement('div');
    msgContainerE1.classList.add("msg-to-chatbot-container");
    chatContainerE1.appendChild(msgContainerE1);

    let userMsg2 = document.createElement("span");
    userMsg2.textContent = userMsg;
    userMsg2.classList.add("msg-to-chatbot");
    msgContainerE1.appendChild(userMsg2);

    userInputE1.value = "";
    botChat();
}

function botChat() {

    let totalBotMsg = chatbotMsgList.length;
    let chatbotMsg = chatbotMsgList[Math.ceil(Math.random() * totalBotMsg) - 1];

    let msgContainerE1 = document.createElement('div');
    msgContainerE1.classList.add("msg-from-chatbot-container");
    chatContainerE1.appendChild(msgContainerE1);

    let botMsg2 = document.createElement("span");
    botMsg2.textContent = chatbotMsg;
    botMsg2.classList.add("msg-from-chatbot");
    msgContainerE1.appendChild(botMsg2);

}